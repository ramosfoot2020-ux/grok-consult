export enum SchedulerQueuesEnum {
  INVITES_QUEUE = 'invitesQueue',
}
