export enum SchedulerNamesEnum {
  REJECT_INVITE = 'rejectInvite',
}
