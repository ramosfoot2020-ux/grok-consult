import { Controller } from '@nestjs/common';

@Controller('uploads')
export class UploadsController {}
