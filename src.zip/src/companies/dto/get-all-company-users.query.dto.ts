import { GetAllUsersQueryDto } from '@src/users-management/dto/get-all-users.query.dto';

export class GetAllCompanyUsersQueryDto extends GetAllUsersQueryDto {}
