import { Controller } from '@nestjs/common';

@Controller('privacy-policies')
export class PrivacyPoliciesController {}
