import { VerifyOtpDto } from './verify-otp.dto';

export class VerifyEmailDto extends VerifyOtpDto {}
