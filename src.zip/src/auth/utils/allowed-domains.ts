export const WHITELISTED_DOMAINS = ['vrealsoft.com', 'bidon-tech.com'];
