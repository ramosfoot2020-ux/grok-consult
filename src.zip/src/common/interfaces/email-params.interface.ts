export interface EmailParamsInterface {
  to: string | string[];
  subject?: string;
  text?: string;
}
