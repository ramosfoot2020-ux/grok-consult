export enum LocaleEnum {
  EN = 'en',
  RU = 'ru',
  UA = 'ua',
}
