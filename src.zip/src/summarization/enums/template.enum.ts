export enum TemplateEnum {
  DAILY = 'daily_standup',
  DEMO = 'demo_review',
  REQUIREMENTS_GATHERING = 'requirements_gathering',
  KICKOFF = 'kick_off',
}
