import { Controller } from '@nestjs/common';

@Controller('user-companies')
export class UserCompaniesController {}
