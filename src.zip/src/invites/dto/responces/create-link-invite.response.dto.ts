import { InviteDto } from './invite.dto';

export class CreateLinkInviteResponseDto extends InviteDto {}
