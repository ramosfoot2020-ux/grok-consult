import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';

import dayjs from 'dayjs';
import { Prisma } from '@prisma/client';

import { PrismaService } from '@src/prisma/prisma.service';
import { UsersService } from '@src/users/users.service';
import { UserPayloadInterface } from '@src/common/interfaces/user-payload.interface';
import { HashService } from '@src/common/services/hash.service';
import { EmailService } from '@src/common/services/email.service';
import { errorMessages } from '@src/common/error-messages';
import { UserCompaniesService } from '@src/user-companies/user-companies.service';
import { RolesEnum } from '@src/users/enums/roles.enum';
import { SchedulerService } from '@src/scheduler/scheduler.service';
import { SchedulerNamesEnum } from '@src/scheduler/enums/scheduler-names.enum';
import { SchedulerQueuesEnum } from '@src/scheduler/enums/scheduler-queues.enum';
import { TokenService } from '@src/common/services/token.service';
import { CompaniesService } from '@src/companies/companies.service';

import { CreateInviteDto } from './dto/create-invite.dto';
import { HandleInviteDto } from './dto/handle-invite.dto';
import { GetAllInvitesQueryDto } from './dto/get-all-invites.query.dto';
import { InviteStatusesEnum } from './enums/invite-statuses.enum';

@Injectable()
export class InvitesService {
  constructor(
    private readonly userCompaniesService: UserCompaniesService,
    private readonly userService: UsersService,
    private readonly prisma: PrismaService,
    private readonly emailService: EmailService,
    private readonly hashService: HashService,
    private readonly schedulerService: SchedulerService,
    private readonly tokenService: TokenService,
    private readonly companiesService: CompaniesService,
  ) {}

  async createEmailInvite(createInviteDto: CreateInviteDto, user: UserPayloadInterface) {
    const now = dayjs();
    const validUntil = now.add(24, 'hours').toDate();

    const sendedInvites = await this.prisma.invite.findMany({
      where: { email: { in: createInviteDto.emails }, rejectedAt: null, acceptedAt: null },
    });

    if (sendedInvites.length) {
      throw new BadRequestException(errorMessages.BadRequestException.INVITE_ALREADY_SENDED());
    }

    const invites = await this.prisma.$transaction(async (prisma) => {
      const inviteData = createInviteDto.emails.map((email) => ({
        email,
        role: createInviteDto.role,
        type: createInviteDto.inviteType,
        companyId: user.companyId,
        validUntil,
      }));

      await prisma.invite.createMany({
        data: inviteData,
        skipDuplicates: true,
      });

      return prisma.invite.findMany({
        where: { email: { in: createInviteDto.emails }, rejectedAt: null, acceptedAt: null },
      });
    });

    await Promise.all(
      invites.map((invite) =>
        this.schedulerService.scheduleJob(
          invite.validUntil,
          SchedulerNamesEnum.REJECT_INVITE,
          { id: invite.id },
          SchedulerQueuesEnum.INVITES_QUEUE,
        ),
      ),
    );

    await Promise.all(
      invites.map((invite) =>
        this.emailService.sendEmail({
          to: invite.email!,
          subject: 'Invitation to join company',
          text: `Accept invitation to join company: ${process.env.APP_CLIENT_URL}/accept-email-invite?inviteId=${invite.id}&expiresAt=${validUntil.toISOString()}`,
        }),
      ),
    );

    return { success: true, count: invites.length };
  }

  async createLinkInvite(createInviteDto: CreateInviteDto, user: UserPayloadInterface) {
    const now = dayjs();
    const validUntil = now.add(24, 'hours').toDate();

    const inviteToken = await this.tokenService.generateTokenForInvite();
    const link = `${process.env.APP_CLIENT_URL}/accept-link-invite?token=${inviteToken}&expiresAt=${validUntil.toISOString()}`;

    const invite = await this.prisma.invite.create({
      data: {
        role: createInviteDto.role,
        companyId: user.companyId,
        link,
        validUntil,
        type: createInviteDto.inviteType,
      },
    });

    await this.schedulerService.scheduleJob(
      invite.validUntil,
      SchedulerNamesEnum.REJECT_INVITE,
      { id: invite.id },
      SchedulerQueuesEnum.INVITES_QUEUE,
    );

    return invite;
  }

  async getInviteById(inviteId: string) {
    return this.prisma.invite.findUnique({
      where: { id: inviteId },
    });
  }

  async acceptLinkInvite(dto: HandleInviteDto) {
    const { token } = dto;

    const invite = await this.getInviteByToken(token);

    if (!invite) {
      throw new NotFoundException(errorMessages.NotFoundException.INVITE_NOT_FOUND());
    }

    const isInviteValid = this.isInviteValid(invite.validUntil);

    if (!isInviteValid) {
      throw new BadRequestException(errorMessages.BadRequestException.INVITE_DATE_IS_EXPIRED());
    }

    const salt = await this.hashService.generateSalt();
    const hashedPassword = await this.hashService.hashPassword(dto.password, salt);

    const result = await this.prisma.$transaction(async (tx) => {
      const existingUser = await this.userService.getUserByEmail(dto.email);
      let invitedUser;

      if (!existingUser) {
        const mainCompany = await this.companiesService.createCompanyRecord(
          {
            name: `${dto.firstName}'s Space`,
          },
          tx,
        );

        invitedUser = await this.userService.createUser(
          {
            email: dto.email,
            firstName: dto.firstName,
            lastName: dto.lastName,
            salt,
            password: hashedPassword,
            mainCompanyId: mainCompany.id,
          },
          tx,
        );

        await this.userCompaniesService.linkUserToCompany(
          {
            userId: invitedUser.id,
            companyId: mainCompany.id,
            role: RolesEnum.OWNER,
          },
          tx,
        );
      } else {
        invitedUser = existingUser;
      }

      await this.userCompaniesService.linkUserToCompany(
        {
          userId: invitedUser.id,
          companyId: invite.companyId,
          role: invite.role as RolesEnum,
        },
        tx,
      );

      const updatedInvite = await tx.invite.update({
        where: { id: invite.id },
        data: {
          acceptedAt: dayjs().toDate(),
        },
      });

      return { invitedUser, updatedInvite };
    });

    return result;
  }

  async acceptEmailInvite(dto: HandleInviteDto) {
    const invite = await this.getInviteById(dto.inviteId);

    if (!invite) {
      throw new BadRequestException(errorMessages.NotFoundException.INVITE_NOT_FOUND());
    }

    const isInviteValid = this.isInviteValid(invite.validUntil);

    if (!isInviteValid) {
      throw new BadRequestException(errorMessages.BadRequestException.INVITE_DATE_IS_EXPIRED());
    }

    if (invite.acceptedAt) {
      throw new BadRequestException(errorMessages.BadRequestException.INVITE_ALREADY_ACCEPTED());
    }

    if (invite.email !== dto.email) {
      throw new BadRequestException(errorMessages.BadRequestException.INVITE_EMAIL_NOT_MATCH());
    }

    const salt = await this.hashService.generateSalt();
    const hashedPassword = await this.hashService.hashPassword(dto.password, salt);

    const result = await this.prisma.$transaction(async (tx) => {
      const existingUser = await this.userService.getUserByEmail(invite.email as string);
      let invitedUser;

      if (!existingUser) {
        const mainCompany = await this.companiesService.createCompanyRecord(
          {
            name: `${dto.firstName}'s Space`,
          },
          tx,
        );

        invitedUser = await this.userService.createUser(
          {
            email: invite.email!,
            firstName: dto.firstName,
            lastName: dto.lastName,
            salt,
            password: hashedPassword,
            mainCompanyId: mainCompany.id,
          },
          tx,
        );

        await this.userCompaniesService.linkUserToCompany(
          {
            userId: invitedUser.id,
            companyId: mainCompany.id,
            role: RolesEnum.OWNER,
          },
          tx,
        );
      } else {
        invitedUser = existingUser;
      }

      await this.userCompaniesService.linkUserToCompany(
        {
          userId: invitedUser.id,
          companyId: invite.companyId,
          role: invite.role as RolesEnum,
        },
        tx,
      );

      const updatedInvite = await tx.invite.update({
        where: { id: invite.id },
        data: {
          acceptedAt: dayjs().toDate(),
        },
      });

      return { invitedUser, updatedInvite };
    });

    return result;
  }

  async getAllInvites(query: GetAllInvitesQueryDto, user: UserPayloadInterface) {
    const { skip = 0, take = 20, roles, status, search } = query;

    const where: Prisma.InviteWhereInput = {
      companyId: user.companyId,
    };

    if (roles?.length) {
      where.role = { in: roles };
    }

    if (search && search?.length > 0) {
      where.OR = [{ email: { contains: search, mode: 'insensitive' } }];
    }

    if (status?.length) {
      const clauses: Prisma.InviteWhereInput[] = [];
      const now = new Date();

      if (status.includes(InviteStatusesEnum.ACCEPTED)) {
        clauses.push({ acceptedAt: { not: null } });
      }
      if (status.includes(InviteStatusesEnum.REJECTED)) {
        clauses.push({ rejectedAt: { not: null } });
      }
      if (status.includes(InviteStatusesEnum.EXPIRED)) {
        clauses.push({ validUntil: { lt: now }, acceptedAt: null, rejectedAt: null });
      }
      if (status.includes(InviteStatusesEnum.PENDING)) {
        clauses.push({
          validUntil: { gte: now },
          acceptedAt: null,
          rejectedAt: null,
        });
      }
      where.OR = clauses;
    }

    const [total, invites] = await this.prisma.$transaction([
      this.prisma.invite.count({ where }),
      this.prisma.invite.findMany({
        where,
        skip,
        take,
        orderBy: { createdAt: 'desc' },
      }),
    ]);

    return { total, invites };
  }

  async rejectInvite(inviteId: string) {
    const invite = await this.getInviteById(inviteId);

    if (!invite) {
      throw new NotFoundException(errorMessages.NotFoundException.INVITE_NOT_FOUND());
    }

    await this.prisma.invite.update({
      where: { id: invite.id },
      data: {
        rejectedAt: dayjs().toDate(),
      },
    });
  }

  async getInviteByToken(token: string) {
    return this.prisma.invite.findFirst({
      where: {
        link: {
          contains: token,
        },
        rejectedAt: null,
      },
    });
  }

  private isInviteValid(inviteValidDate: Date) {
    return dayjs(inviteValidDate).isAfter(dayjs());
  }
}
