export enum InviteTypesEnum {
  EMAIL = 'email',
  LINK = 'link',
}
