export enum InviteStatusesEnum {
  ACCEPTED = 'ACCEPTED',
  REJECTED = 'REJECTED',
  EXPIRED = 'EXPIRED',
  PENDING = 'PENDING',
}
