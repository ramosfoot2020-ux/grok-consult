import { VerifyOtpDto } from '@src/auth/dto/verify-otp.dto';

export class VerifyEmailDto extends VerifyOtpDto {}
