export enum RolesEnum {
  OWNER = 'OWNER',
  ADMIN = 'ADMIN',
  USER = 'USER',
  COMPANY_MANAGER = 'COMPANY_MANAGER',
}
