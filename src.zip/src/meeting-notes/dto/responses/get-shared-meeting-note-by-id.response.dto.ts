import { MeetingNoteResponseDto } from '@src/meeting-notes/dto/responses/get-meeting-note-bu-id.reponse.dto';

export class SharedMeetingNoteResponseDto extends MeetingNoteResponseDto {}
