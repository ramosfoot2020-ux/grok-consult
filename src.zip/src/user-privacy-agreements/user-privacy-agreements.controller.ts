import { Controller } from '@nestjs/common';

@Controller('user-privacy-agreements')
export class UserPrivacyAgreementsController {}
