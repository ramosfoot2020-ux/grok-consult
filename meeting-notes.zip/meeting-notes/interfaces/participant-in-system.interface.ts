export interface ParticipantInSystemInterface {
  id: string;
}
