import { ApiProperty } from '@nestjs/swagger';

import { IsString, IsOptional, IsInt, IsBoolean } from 'class-validator';

export class UpdateCommentDto {
  @ApiProperty({ required: true })
  @IsOptional()
  @IsString()
  content?: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsInt()
  from?: number;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsInt()
  to?: number;

  @ApiProperty({
    description: '',
    default: false,
    type: Boolean,
  })
  @IsBoolean()
  resolved: boolean = false;
}
