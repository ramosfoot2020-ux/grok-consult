import { ApiProperty } from '@nestjs/swagger';

import { IsString, IsOptional, IsInt, IsNotEmpty } from 'class-validator';

export class CreateCommentDto {
  @ApiProperty({ required: true })
  @IsNotEmpty()
  @IsString()
  content!: string;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsInt()
  from?: number;

  @ApiProperty({ required: false })
  @IsOptional()
  @IsInt()
  to?: number;
}
