-- AlterTable
ALTER TABLE "MeetingNote" ADD COLUMN     "additionalBlocks" JSONB;
