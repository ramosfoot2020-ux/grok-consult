-- AlterTable
ALTER TABLE "Company" ADD COLUMN     "avatar" TEXT;
