-- AlterTable
ALTER TABLE "User" ADD COLUMN     "timeZone" TEXT;
