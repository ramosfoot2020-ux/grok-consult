-- AlterTable
ALTER TABLE "MeetingNote" ADD COLUMN     "additionalBlocksAfter" JSONB NOT NULL DEFAULT '[]';
