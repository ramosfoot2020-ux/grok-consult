-- AlterTable
ALTER TABLE "MeetingNote" ADD COLUMN     "isHidden" BOOLEAN NOT NULL DEFAULT false;
