/*
  Warnings:

  - You are about to drop the column `locationId` on the `MeetingNote` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "MeetingNote" DROP COLUMN "locationId";
